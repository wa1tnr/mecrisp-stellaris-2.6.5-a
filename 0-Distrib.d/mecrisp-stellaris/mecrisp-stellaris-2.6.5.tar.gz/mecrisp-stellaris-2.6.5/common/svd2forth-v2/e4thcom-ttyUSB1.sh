#!/bin/sh
e4thcom -t mecrisp-st -d ttyUSB1 -b B115200	| tee e4thcom.log
