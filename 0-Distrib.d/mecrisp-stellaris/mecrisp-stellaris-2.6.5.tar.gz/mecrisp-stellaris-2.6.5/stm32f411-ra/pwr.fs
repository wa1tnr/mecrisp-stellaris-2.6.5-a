$40007000 constant PWR     ( Power control ) 
PWR $0 +  constant PWR_CR  ( read-write    ) \ power control register
PWR $4 +  constant PWR_CSR (               ) \ power control/status register
